# Instruction

1. Active a Google Search Consolse API
2. Create an OAuth 2.0 client ID. 
3. Download the client_secret.json file and save it as gsc_keys.json to the same directory as this script.